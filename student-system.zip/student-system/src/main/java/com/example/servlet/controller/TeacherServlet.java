package com.example.servlet.controller;

import com.example.servlet.dao.TeacherDao;
import com.example.servlet.model.Teacher;
import com.google.gson.Gson;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TeacherServlet extends HttpServlet {
    private TeacherDao teacherDao = new TeacherDao();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json;charset=UTF-8");
        PrintWriter out = resp.getWriter();

        String pageStr = req.getParameter("page");
        String pageSizeStr = req.getParameter("pageSize");

        int page = pageStr != null ? Integer.parseInt(pageStr) : 1;
        int pageSize = pageSizeStr != null ? Integer.parseInt(pageSizeStr) : 5;
        int offset = (page - 1) * pageSize;

        List<Teacher> teachers = teacherDao.findByPage(offset, pageSize);
        int total = teacherDao.count();

        // ✅ 用 HashMap 构建响应体
        Map<String, Object> result = new HashMap<>();
        result.put("totalCount", total);
        result.put("data", teachers);

        String json = new Gson().toJson(result);
        out.print(json);
        out.close();
    }


    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json;charset=UTF-8");

        BufferedReader reader = req.getReader();
        Teacher t = new Gson().fromJson(reader, Teacher.class);
        boolean success = teacherDao.insert(t);

        PrintWriter out = resp.getWriter();
        if (success) {
            out.print("{\"msg\":\"添加成功\"}");
        } else {
            resp.setStatus(500);
            out.print("{\"error\":\"添加失败\"}");
        }
        out.close();
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json;charset=UTF-8");

        BufferedReader reader = req.getReader();
        Teacher t = new Gson().fromJson(reader, Teacher.class);
        boolean success = teacherDao.update(t);

        PrintWriter out = resp.getWriter();
        if (success) {
            out.print("{\"msg\":\"修改成功\"}");
        } else {
            resp.setStatus(500);
            out.print("{\"error\":\"修改失败\"}");
        }
        out.close();
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String sid = req.getParameter("id");
        resp.setContentType("application/json;charset=UTF-8");
        PrintWriter out = resp.getWriter();

        if (sid != null) {
            int id = Integer.parseInt(sid);
            boolean success = teacherDao.delete(id);
            if (success) {
                out.print("{\"msg\":\"删除成功\"}");
            } else {
                resp.setStatus(500);
                out.print("{\"error\":\"删除失败\"}");
            }
        } else {
            resp.setStatus(400);
            out.print("{\"error\":\"缺少参数 id\"}");
        }
        out.close();
    }
}
package com.example.servlet.model;

import java.util.List;

public class CourseResponse {
    private int totalCount;
    private List<Course> data;

    public CourseResponse(int totalCount, List<Course> data) {
        this.totalCount = totalCount;
        this.data = data;
    }

    public int getTotalCount() {
        return totalCount;
    }

    public List<Course> getData() {
        return data;
    }
}

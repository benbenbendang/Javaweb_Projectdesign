package com.example.servlet.controller;

import com.example.servlet.model.User;
import com.example.servlet.service.UserService;
import com.google.gson.Gson;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.io.PrintWriter;

public class LoginServlet extends HttpServlet {
    private UserService userService = new UserService();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");

        // 读取 JSON 请求体
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = request.getReader().readLine()) != null) {
            sb.append(line);
        }

        // 使用 Gson 解析 JSON
        Gson gson = new Gson();
        User reqUser = gson.fromJson(sb.toString(), User.class);
        String username = reqUser.getUsername();
        String password = reqUser.getPassword();

        // 校验用户
        User user = userService.login(username, password);
        PrintWriter out = response.getWriter();
        if (user != null) {
            HttpSession session = request.getSession();
            session.setAttribute("user", user);
            out.print(gson.toJson(user));
        } else {
            response.setStatus(401);
            out.print("{\"error\":\"用户名或密码错误\"}");
        }
        out.close();
    }

}

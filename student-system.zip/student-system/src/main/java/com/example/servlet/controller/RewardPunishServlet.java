package com.example.servlet.controller;

import com.example.servlet.dao.RewardPunishDao;
import com.example.servlet.model.RewardPunish;
import com.google.gson.Gson;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.util.List;

public class RewardPunishServlet extends HttpServlet {
    private RewardPunishDao rewardDao = new RewardPunishDao();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json;charset=UTF-8");
        PrintWriter out = resp.getWriter();

        String pageStr = req.getParameter("page");
        String pageSizeStr = req.getParameter("pageSize");

        int page = pageStr != null ? Integer.parseInt(pageStr) : 1;
        int pageSize = pageSizeStr != null ? Integer.parseInt(pageSizeStr) : 5;
        int offset = (page - 1) * pageSize;

        List<RewardPunish> list = rewardDao.findByPage(offset, pageSize);
        int total = rewardDao.count();

        if (list == null) list = new java.util.ArrayList<>();

        java.util.Map<String, Object> result = new java.util.HashMap<>();
        result.put("totalCount", total);
        result.put("data", list);

        String json = new Gson().toJson(result);
        out.print(json);
        out.close();  // ✅ 一定要加上
        System.out.println("RewardPunishServlet 被调用");
        System.out.println("返回JSON：" + json);
    }


    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json;charset=UTF-8");

        RewardPunish rp = new Gson().fromJson(req.getReader(), RewardPunish.class);
        boolean success = rewardDao.insert(rp);

        PrintWriter out = resp.getWriter();
        if (success) {
            out.print("{\"msg\":\"添加成功\"}");
        } else {
            resp.setStatus(500);
            out.print("{\"error\":\"添加失败\"}");
        }
        out.close();
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json;charset=UTF-8");

        RewardPunish rp = new Gson().fromJson(req.getReader(), RewardPunish.class);
        boolean success = rewardDao.update(rp);

        PrintWriter out = resp.getWriter();
        if (success) {
            out.print("{\"msg\":\"修改成功\"}");
        } else {
            resp.setStatus(500);
            out.print("{\"error\":\"修改失败\"}");
        }
        out.close();
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String sid = req.getParameter("id");
        resp.setContentType("application/json;charset=UTF-8");
        PrintWriter out = resp.getWriter();

        if (sid != null) {
            int id = Integer.parseInt(sid);
            boolean success = rewardDao.delete(id);
            if (success) {
                out.print("{\"msg\":\"删除成功\"}");
            } else {
                resp.setStatus(500);
                out.print("{\"error\":\"删除失败\"}");
            }
        } else {
            resp.setStatus(400);
            out.print("{\"error\":\"缺少参数 id\"}");
        }
        out.close();
    }
}

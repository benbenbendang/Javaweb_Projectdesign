package com.example.servlet.dao;

import com.example.servlet.model.Student;
import com.example.servlet.utils.DbUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentDao {

    public List<Student> findAll() {
        List<Student> list = new ArrayList<>();
        try (Connection conn = DbUtil.getConnection()) {
            String sql = "SELECT * FROM students WHERE isdelete = FALSE";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                Student s = new Student();
                s.setId(rs.getInt("id"));
                s.setName(rs.getString("name"));
                s.setGender(rs.getString("gender"));
                s.setBirthday(rs.getString("birthday"));
                s.setClassName(rs.getString("class_name"));
                s.setMajor(rs.getString("major"));
                s.setPhone(rs.getString("phone"));
                s.setEmail(rs.getString("email"));
                list.add(s);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public boolean insert(Student s) {
        try (Connection conn = DbUtil.getConnection()) {
            String sql = "INSERT INTO students(name, gender, birthday, class_name, major, phone, email) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, s.getName());
            ps.setString(2, s.getGender());
            ps.setString(3, s.getBirthday());
            ps.setString(4, s.getClassName());
            ps.setString(5, s.getMajor());
            ps.setString(6, s.getPhone());
            ps.setString(7, s.getEmail());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean update(Student s) {
        try (Connection conn = DbUtil.getConnection()) {
            String sql = "UPDATE students SET name=?, gender=?, birthday=?, class_name=?, major=?, phone=?, email=? " +
                    "WHERE id=? AND isdelete=FALSE";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, s.getName());
            ps.setString(2, s.getGender());
            ps.setString(3, s.getBirthday());
            ps.setString(4, s.getClassName());
            ps.setString(5, s.getMajor());
            ps.setString(6, s.getPhone());
            ps.setString(7, s.getEmail());
            ps.setInt(8, s.getId());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean delete(int id) {
        try (Connection conn = DbUtil.getConnection()) {
            String sql = "UPDATE students SET isdelete=TRUE WHERE id=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<Student> findByPage(int offset, int limit) {
        List<Student> list = new ArrayList<>();
        try (Connection conn = DbUtil.getConnection()) {
            String sql = "SELECT * FROM students WHERE isdelete = FALSE LIMIT ? OFFSET ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, limit);
            ps.setInt(2, offset);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Student s = new Student();
                s.setId(rs.getInt("id"));
                s.setName(rs.getString("name"));
                s.setGender(rs.getString("gender"));
                s.setBirthday(rs.getString("birthday"));
                s.setClassName(rs.getString("class_name"));
                s.setMajor(rs.getString("major"));
                s.setPhone(rs.getString("phone"));
                s.setEmail(rs.getString("email"));
                list.add(s);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public int count() {
        try (Connection conn = DbUtil.getConnection()) {
            String sql = "SELECT COUNT(*) FROM students WHERE isdelete = FALSE";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public List<Student> search(String keyword, int offset, int limit) {
        List<Student> list = new ArrayList<>();
        try (Connection conn = DbUtil.getConnection()) {
            String sql = "SELECT * FROM students WHERE isdelete = FALSE AND " +
                    "(name LIKE ? OR class_name LIKE ? OR major LIKE ?) " +
                    "LIMIT ? OFFSET ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            String like = "%" + keyword + "%";
            ps.setString(1, like);
            ps.setString(2, like);
            ps.setString(3, like);
            ps.setInt(4, limit);
            ps.setInt(5, offset);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Student s = new Student();
                s.setId(rs.getInt("id"));
                s.setName(rs.getString("name"));
                s.setGender(rs.getString("gender"));
                s.setBirthday(rs.getString("birthday"));
                s.setClassName(rs.getString("class_name"));
                s.setMajor(rs.getString("major"));
                s.setPhone(rs.getString("phone"));
                s.setEmail(rs.getString("email"));
                list.add(s);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public int countSearch(String keyword) {
        try (Connection conn = DbUtil.getConnection()) {
            String sql = "SELECT COUNT(*) FROM students WHERE isdelete = FALSE AND " +
                    "(name LIKE ? OR class_name LIKE ? OR major LIKE ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            String like = "%" + keyword + "%";
            ps.setString(1, like);
            ps.setString(2, like);
            ps.setString(3, like);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
}

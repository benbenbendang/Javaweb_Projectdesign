// === com.example.servlet.controller.AttendanceServlet ===
package com.example.servlet.controller;

import com.example.servlet.dao.AttendanceDao;
import com.example.servlet.model.Attendance;
import com.google.gson.Gson;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

public class AttendanceServlet extends HttpServlet {
    private AttendanceDao dao = new AttendanceDao();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        resp.setContentType("application/json;charset=UTF-8");
        PrintWriter out = resp.getWriter();

        int page = parseInt(req.getParameter("page"), 1);
        int pageSize = parseInt(req.getParameter("pageSize"), 5);
        int offset = (page - 1) * pageSize;

        List<Attendance> list = dao.findByPage(offset, pageSize);
        int total = dao.count();

        String json = new Gson().toJson(new Object() {
            final int totalCount = total;
            final List<Attendance> data = list;
        });

        out.print(json);
        out.close();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        BufferedReader reader = req.getReader();
        Attendance a = new Gson().fromJson(reader, Attendance.class);

        boolean ok = dao.insert(a);
        writeResponse(resp, ok, "添加成功", "添加失败");
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        BufferedReader reader = req.getReader();
        Attendance a = new Gson().fromJson(reader, Attendance.class);

        boolean ok = dao.update(a);
        writeResponse(resp, ok, "修改成功", "修改失败");
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String sid = req.getParameter("id");
        boolean ok = sid != null && dao.delete(Integer.parseInt(sid));
        writeResponse(resp, ok, "删除成功", "删除失败");
    }

    private void writeResponse(HttpServletResponse resp, boolean ok, String msg, String err)
            throws IOException {
        resp.setContentType("application/json;charset=UTF-8");
        PrintWriter out = resp.getWriter();
        if (ok) {
            out.print("{\"msg\":\"" + msg + "\"}");
        } else {
            resp.setStatus(500);
            out.print("{\"error\":\"" + err + "\"}");
        }
        out.close();
    }

    private int parseInt(String str, int defaultVal) {
        try {
            return Integer.parseInt(str);
        } catch (Exception e) {
            return defaultVal;
        }
    }
}

package com.example.servlet.dao;

import com.example.servlet.model.Attendance;
import com.example.servlet.utils.DbUtil;

import java.sql.*;
import java.util.*;

public class AttendanceDao {

    public List<Attendance> findByPage(int offset, int limit) {
        List<Attendance> list = new ArrayList<>();
        try (Connection conn = DbUtil.getConnection()) {
            String sql = "SELECT * FROM attendances WHERE isdelete=FALSE LIMIT ? OFFSET ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, limit);
            ps.setInt(2, offset);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Attendance a = new Attendance();
                a.setId(rs.getInt("id"));
                a.setStudentId(rs.getInt("student_id"));
                a.setStatus(rs.getString("status"));
                a.setDate(rs.getString("date"));
                list.add(a);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public int count() {
        try (Connection conn = DbUtil.getConnection()) {
            String sql = "SELECT COUNT(*) FROM attendances WHERE isdelete=FALSE";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            if (rs.next()) return rs.getInt(1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public boolean insert(Attendance a) {
        try (Connection conn = DbUtil.getConnection()) {
            String sql = "INSERT INTO attendances(student_id, status, date) VALUES (?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, a.getStudentId());
            ps.setString(2, a.getStatus());
            ps.setString(3, a.getDate());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean update(Attendance a) {
        try (Connection conn = DbUtil.getConnection()) {
            String sql = "UPDATE attendances SET student_id=?, status=?, date=? WHERE id=? AND isdelete=FALSE";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, a.getStudentId());
            ps.setString(2, a.getStatus());
            ps.setString(3, a.getDate());
            ps.setInt(4, a.getId());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean delete(int id) {
        try (Connection conn = DbUtil.getConnection()) {
            String sql = "UPDATE attendances SET isdelete=TRUE WHERE id=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}

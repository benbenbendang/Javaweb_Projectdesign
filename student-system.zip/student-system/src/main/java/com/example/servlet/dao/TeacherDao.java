package com.example.servlet.dao;

import com.example.servlet.model.Teacher;
import com.example.servlet.utils.DbUtil;

import java.sql.*;
import java.util.*;

public class TeacherDao {
    public List<Teacher> findByPage(int offset, int limit) {
        List<Teacher> list = new ArrayList<>();
        try (Connection conn = DbUtil.getConnection()) {
            String sql = "SELECT * FROM teachers WHERE isdelete=FALSE LIMIT ? OFFSET ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, limit);
            ps.setInt(2, offset);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Teacher t = new Teacher();
                t.setId(rs.getInt("id"));
                t.setName(rs.getString("name"));
                t.setGender(rs.getString("gender"));
                t.setTitle(rs.getString("title"));
                t.setDepartment(rs.getString("department"));
                t.setPhone(rs.getString("phone"));
                t.setEmail(rs.getString("email"));
                list.add(t);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public int count() {
        try (Connection conn = DbUtil.getConnection()) {
            String sql = "SELECT COUNT(*) FROM teachers WHERE isdelete=FALSE";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public boolean insert(Teacher t) {
        try (Connection conn = DbUtil.getConnection()) {
            String sql = "INSERT INTO teachers(name, gender, title, department, phone, email) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, t.getName());
            ps.setString(2, t.getGender());
            ps.setString(3, t.getTitle());
            ps.setString(4, t.getDepartment());
            ps.setString(5, t.getPhone());
            ps.setString(6, t.getEmail());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean update(Teacher t) {
        try (Connection conn = DbUtil.getConnection()) {
            String sql = "UPDATE teachers SET name=?, gender=?, title=?, department=?, phone=?, email=? WHERE id=? AND isdelete=FALSE";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, t.getName());
            ps.setString(2, t.getGender());
            ps.setString(3, t.getTitle());
            ps.setString(4, t.getDepartment());
            ps.setString(5, t.getPhone());
            ps.setString(6, t.getEmail());
            ps.setInt(7, t.getId());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean delete(int id) {
        try (Connection conn = DbUtil.getConnection()) {
            String sql = "UPDATE teachers SET isdelete=TRUE WHERE id=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
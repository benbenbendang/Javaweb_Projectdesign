package com.example.servlet.service;

import com.example.servlet.dao.UserDao;
import com.example.servlet.model.User;

public class UserService {
    private UserDao userDao = new UserDao();

    public User login(String username, String password) {
        return userDao.findByUsernameAndPassword(username, password);
    }
}

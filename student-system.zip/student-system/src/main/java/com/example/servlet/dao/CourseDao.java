package com.example.servlet.dao;

import com.example.servlet.model.Course;
import com.example.servlet.utils.DbUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CourseDao {
    public List<Course> findByPage(int offset, int limit) {
        List<Course> list = new ArrayList<>();
        try (Connection conn = DbUtil.getConnection()) {
            String sql = "SELECT * FROM courses WHERE isdelete = FALSE LIMIT ? OFFSET ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, limit);
            ps.setInt(2, offset);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Course c = new Course();
                c.setId(rs.getInt("id"));
                c.setName(rs.getString("name"));
                c.setTeacher(rs.getString("teacher"));
                c.setSchedule(rs.getString("schedule"));
                list.add(c);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public int count() {
        try (Connection conn = DbUtil.getConnection()) {
            String sql = "SELECT COUNT(*) FROM courses WHERE isdelete = FALSE";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public boolean insert(Course c) {
        try (Connection conn = DbUtil.getConnection()) {
            String sql = "INSERT INTO courses(name, teacher, schedule) VALUES (?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, c.getName());
            ps.setString(2, c.getTeacher());
            ps.setString(3, c.getSchedule());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean update(Course c) {
        try (Connection conn = DbUtil.getConnection()) {
            String sql = "UPDATE courses SET name=?, teacher=?, schedule=? WHERE id=? AND isdelete=FALSE";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, c.getName());
            ps.setString(2, c.getTeacher());
            ps.setString(3, c.getSchedule());
            ps.setInt(4, c.getId());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean delete(int id) {
        try (Connection conn = DbUtil.getConnection()) {
            String sql = "UPDATE courses SET isdelete=TRUE WHERE id=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}

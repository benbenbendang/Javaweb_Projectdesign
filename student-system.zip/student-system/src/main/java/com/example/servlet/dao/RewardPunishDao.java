package com.example.servlet.dao;

import com.example.servlet.model.RewardPunish;
import com.example.servlet.utils.DbUtil;

import java.sql.*;
import java.util.*;

public class RewardPunishDao {
    public List<RewardPunish> findByPage(int offset, int limit) {
        List<RewardPunish> list = new ArrayList<>();
        try (Connection conn = DbUtil.getConnection()) {
            String sql = "SELECT * FROM reward_punish WHERE isdelete=FALSE LIMIT ? OFFSET ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, limit);
            ps.setInt(2, offset);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                RewardPunish rp = new RewardPunish();
                rp.setId(rs.getInt("id"));
                rp.setStudentId(rs.getInt("student_id"));
                rp.setType(rs.getString("type"));
                rp.setDescription(rs.getString("description"));
                rp.setDate(rs.getString("date"));
                list.add(rp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public int count() {
        try (Connection conn = DbUtil.getConnection()) {
            String sql = "SELECT COUNT(*) FROM reward_punish WHERE isdelete=FALSE";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public boolean insert(RewardPunish rp) {
        try (Connection conn = DbUtil.getConnection()) {
            String sql = "INSERT INTO reward_punish(student_id, type, description, date) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, rp.getStudentId());
            ps.setString(2, rp.getType());
            ps.setString(3, rp.getDescription());
            ps.setString(4, rp.getDate());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean update(RewardPunish rp) {
        try (Connection conn = DbUtil.getConnection()) {
            String sql = "UPDATE reward_punish SET student_id=?, type=?, description=?, date=? WHERE id=? AND isdelete=FALSE";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, rp.getStudentId());
            ps.setString(2, rp.getType());
            ps.setString(3, rp.getDescription());
            ps.setString(4, rp.getDate());
            ps.setInt(5, rp.getId());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean delete(int id) {
        try (Connection conn = DbUtil.getConnection()) {
            String sql = "UPDATE reward_punish SET isdelete=TRUE WHERE id=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
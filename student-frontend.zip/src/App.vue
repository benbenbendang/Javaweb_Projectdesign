<template>
  <div id="app">
    <!-- 顶部菜单栏 -->
    <div style="display: flex; justify-content: space-between; align-items: center; background-color: #545c64; padding: 10px 20px;">
      <div style="color: #fff; font-size: 20px;">学生信息管理系统</div>
      <el-button type="danger" size="small" @click="$router.push('/login')">
        退出登录
      </el-button>
    </div>

    <!-- 页面内容 -->
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
  margin-top: 0;
}
</style>

import Vue from 'vue'
import Router from 'vue-router'
import LoginPage from '@/views/Login.vue'
import StudentList from '@/views/StudentList.vue'
import TeacherList from '@/views/TeacherList.vue'
import AdminDashboard from '@/views/AdminDashboard.vue'
import RewardPunishList from '@/views/RewardPunishList.vue'
import CourseList from '@/views/CourseList.vue'

Vue.use(Router)

export default new Router({
    routes: [
        { path: '/', redirect: '/login' },
        { path: '/login', component: LoginPage },
        { path: '/students', component: StudentList },
        { path: '/teachers', component: TeacherList },
        { path: '/admin', component: AdminDashboard },
        { path: '/rewards', component: RewardPunishList },
        { path: '/attendances', component: () => import('@/views/AttendanceList.vue') },
        { path: '/courses', component: CourseList }]
})

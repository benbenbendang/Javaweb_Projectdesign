<template>
  <div style="padding: 20px">
    <el-button type="primary" @click="openDialog()">添加记录</el-button>

    <el-table :data="records" style="width: 100%; margin-top: 20px">
      <el-table-column prop="id" label="ID" width="60" />
      <el-table-column prop="studentId" label="学生ID" />
      <el-table-column prop="type" label="类型" />
      <el-table-column prop="description" label="描述" />
      <el-table-column prop="date" label="日期" />
      <el-table-column label="操作" width="160">
        <template slot-scope="scope">
          <el-button size="mini" @click="openDialog(scope.row)">编辑</el-button>
          <el-button size="mini" type="danger" @click="handleDelete(scope.row.id)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-pagination
        layout="total, prev, pager, next, jumper"
        :total="total"
        :page-size="pageSize"
        :current-page="currentPage"
        @current-change="handlePageChange"
        style="margin-top: 20px; text-align: center"
    />

    <el-dialog :title="form.id ? '编辑记录' : '添加记录'" :visible.sync="dialogVisible">
      <el-form :model="form" label-width="80px">
        <el-form-item label="学生ID"><el-input v-model="form.studentId" /></el-form-item>
        <el-form-item label="类型">
          <el-select v-model="form.type" placeholder="请选择">
            <el-option label="奖励" value="奖励" />
            <el-option label="惩罚" value="惩罚" />
          </el-select>
        </el-form-item>
        <el-form-item label="描述"><el-input v-model="form.description" /></el-form-item>
        <el-form-item label="日期"><el-date-picker v-model="form.date" type="date" /></el-form-item>
      </el-form>
      <div slot="footer">
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submitForm">提交</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import axios from 'axios'
import dayjs from 'dayjs'

export default {
  name: 'RewardPunishList',
  data() {
    return {
      records: [],
      dialogVisible: false,
      form: {
        id: null, studentId: '', type: '', description: '', date: ''
      },
      currentPage: 1,
      pageSize: 5,
      total: 0
    }
  },
  methods: {
    fetchData() {
      axios.get('/api/rewards', {
        params: {
          page: this.currentPage,
          pageSize: this.pageSize
        }
      }).then(res => {
        const data = res.data || {}
        this.records = data.data || []
        this.total = data.totalCount || 0
      })
    },
    handlePageChange(page) {
      this.currentPage = page
      this.fetchData()
    },
    openDialog(row = null) {
      this.form = row ? Object.assign({}, row) : {
        id: null, studentId: '', type: '', description: '', date: ''
      }
      this.dialogVisible = true
    },
    handleDelete(id) {
      this.$confirm('确认删除该记录吗？', '提示', { type: 'warning' })
          .then(() => {
            axios.delete(`/api/rewards?id=${id}`).then(() => {
              this.$message.success('删除成功')
              this.fetchData()
            })
          })
    },
    submitForm() {
      const isEdit = !!this.form.id
      const url = '/api/rewards'
      const method = isEdit ? 'put' : 'post'
      axios({
        method,
        url,
        data: {
          ...this.form,
          date: this.form.date ? dayjs(this.form.date).format('YYYY-MM-DD') : ''
        }
      }).then(() => {
        this.$message.success(isEdit ? '修改成功' : '添加成功')
        this.dialogVisible = false
        this.fetchData()
      })
    }
  },
  mounted() {
    this.fetchData()
  }
}
</script>

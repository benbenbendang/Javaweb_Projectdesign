<template>
  <div style="padding: 50px; text-align: center">
    <h2>欢迎，学生用户！</h2>
    <p>这是学生主页，你可以在这里查看你的课表、考勤记录和奖惩信息。</p>

    <el-button type="primary" @click="$router.push('/login')" style="margin-top: 20px">
      返回登录
    </el-button>
  </div>
</template>

<script>
export default {
  name: 'StudentHome'
}
</script>

<template>
  <div style="padding: 20px">
    <el-button type="primary" @click="openDialog()">添加教师</el-button>

    <el-table :data="teachers" style="width: 100%; margin-top: 20px">
      <el-table-column prop="id" label="ID" width="60" />
      <el-table-column prop="name" label="姓名" />
      <el-table-column prop="gender" label="性别" />
      <el-table-column prop="title" label="职称" />
      <el-table-column prop="department" label="学院" />
      <el-table-column prop="phone" label="电话" />
      <el-table-column prop="email" label="邮箱" />
      <el-table-column label="操作" width="160">
        <template slot-scope="scope">
          <el-button size="mini" @click="handleEdit(scope.row)">编辑</el-button>
          <el-button size="mini" type="danger" @click="handleDelete(scope.row.id)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-pagination
        layout="total, prev, pager, next, jumper"
        :total="total"
        :page-size="pageSize"
        :current-page="currentPage"
        @current-change="handlePageChange"
        style="margin-top: 20px; text-align: center"
    />

    <el-dialog :title="form.id ? '编辑教师' : '添加教师'" :visible.sync="dialogVisible">
      <el-form :model="form" label-width="80px">
        <el-form-item label="姓名"><el-input v-model="form.name" /></el-form-item>
        <el-form-item label="性别">
          <el-select v-model="form.gender" placeholder="请选择">
            <el-option label="男" value="男" />
            <el-option label="女" value="女" />
          </el-select>
        </el-form-item>
        <el-form-item label="职称"><el-input v-model="form.title" /></el-form-item>
        <el-form-item label="学院"><el-input v-model="form.department" /></el-form-item>
        <el-form-item label="电话"><el-input v-model="form.phone" /></el-form-item>
        <el-form-item label="邮箱"><el-input v-model="form.email" /></el-form-item>
      </el-form>
      <div slot="footer">
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submitForm">提交</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'TeacherList',
  data() {
    return {
      teachers: [],
      dialogVisible: false,
      form: {
        id: null, name: '', gender: '', title: '',
        department: '', phone: '', email: ''
      },
      currentPage: 1,
      pageSize: 5,
      total: 0
    }
  },
  methods: {
    fetchData() {
      axios.get('/api/teachers', {
        params: {
          page: this.currentPage,
          pageSize: this.pageSize
        }
      }).then(res => {
        this.teachers = res.data.data || []
        this.total = res.data.totalCount || 0
      }).catch(err => {
        this.$message.error('加载数据失败')
        console.error(err)
      })
    },
    handlePageChange(page) {
      this.currentPage = page
      this.fetchData()
    },
    openDialog() {
      this.form = { id: null, name: '', gender: '', title: '', department: '', phone: '', email: '' }
      this.dialogVisible = true
    },
    handleEdit(row) {
      this.form = Object.assign({}, row)
      this.dialogVisible = true
    },
    handleDelete(id) {
      this.$confirm('确认删除该教师吗？', '提示', { type: 'warning' })
          .then(() => {
            axios.delete(`/api/teachers?id=${id}`).then(() => {
              this.$message.success('删除成功')
              this.fetchData()
            })
          })
    },
    submitForm() {
      const isEdit = !!this.form.id
      const method = isEdit ? 'put' : 'post'
      axios({
        method,
        url: '/api/teachers',
        data: this.form
      }).then(() => {
        this.$message.success(isEdit ? '修改成功' : '添加成功')
        this.dialogVisible = false
        this.fetchData()
      }).catch(() => {
        this.$message.error('操作失败')
      })
    }
  },
  mounted() {
    this.fetchData()
  }
}
</script>

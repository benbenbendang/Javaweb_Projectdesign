<template>
  <div class="dashboard-container">
    <el-card class="dashboard-card">
      <h2 class="dashboard-title">管理员功能面板</h2>
      <div class="button-group">
        <el-button type="primary" icon="el-icon-document" @click="$router.push('/rewards')">
          奖惩记录管理
        </el-button>
        <el-button type="success" icon="el-icon-notebook-2" @click="$router.push('/courses')">
          课程信息管理
        </el-button>
        <el-button type="info" icon="el-icon-user" @click="$router.push('/students')">
          学生管理
        </el-button>
        <el-button type="warning" icon="el-icon-s-custom" @click="$router.push('/teachers')">
          教师管理
        </el-button>
      </div>
    </el-card>
  </div>
</template>

<script>
export default {
  name: 'AdminDashboard'
}
</script>

<style scoped>
.dashboard-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background: linear-gradient(to right, #dfe9f3, #ffffff);
}

.dashboard-card {
  width: 500px;
  padding: 30px;
  border-radius: 12px;
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
}

.dashboard-title {
  text-align: center;
  font-size: 24px;
  margin-bottom: 30px;
  color: #333;
}

.button-group {
  display: flex;
  flex-direction: column;
  gap: 15px;
}
</style>

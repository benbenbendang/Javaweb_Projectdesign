<!-- eslint-disable vue/multi-word-component-names -->
<template>
  <div class="login-container">
    <div class="login-box">
      <h2 class="login-title">高校信息管理系统</h2>
      <el-form :model="form" label-width="80px">
        <el-form-item label="用户名">
          <el-input v-model="form.username" placeholder="请输入用户名">
            <template #prefix>
              <i class="el-icon-user" />
            </template>
          </el-input>
        </el-form-item>

        <el-form-item label="密码">
          <el-input v-model="form.password" type="password" placeholder="请输入密码">
            <template #prefix>
              <i class="el-icon-lock" />
            </template>
          </el-input>
        </el-form-item>

        <el-form-item label="身份">
          <el-select v-model="form.role" placeholder="请选择身份">
            <el-option label="学生" value="student" />
            <el-option label="教师" value="teacher" />
            <el-option label="管理员" value="admin" />
          </el-select>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="handleLogin" class="login-btn">登录</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
import axios from 'axios'
export default {
  data() {
    return {
      form: {
        username: '',
        password: '',
        role: ''
      }
    }
  },
  methods: {
    handleLogin() {
      axios.post('/api/login', this.form)
          .then(res => {
            localStorage.setItem('user', JSON.stringify(res.data))
            if (this.form.role === 'admin') {
              this.$router.push('/admin')
            } else if (this.form.role === 'teacher') {
              this.$router.push('/teachers')
            } else if (this.form.role === 'student') {
              this.$router.push('/students')
            } else {
              this.$message.error('请选择正确身份')
            }
          })
          .catch(() => {
            this.$message.error('登录失败')
          })
    }
  }
}
</script>

<style scoped>
.login-container {
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  background: linear-gradient(to right, #a1c4fd, #c2e9fb);
}

.login-box {
  width: 380px;
  padding: 30px 40px;
  background-color: #fff;
  border-radius: 16px;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
}

.login-title {
  text-align: center;
  margin-bottom: 24px;
  font-size: 24px;
  color: #333;
}

.el-input__inner {
  border-radius: 8px;
}

.login-btn {
  width: 100%;
  border-radius: 8px;
  font-weight: bold;
}
</style>

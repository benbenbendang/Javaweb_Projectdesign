<template>
  <div style="padding: 20px">
    <el-button type="primary" @click="handleAdd">添加学生</el-button>

    <el-table :data="students" style="width: 100%; margin-top: 20px">
      <el-table-column prop="id" label="ID" width="60" />
      <el-table-column prop="name" label="姓名" />
      <el-table-column prop="gender" label="性别" />
      <el-table-column prop="birthday" label="出生日期" />
      <el-table-column prop="className" label="班级" />
      <el-table-column prop="major" label="专业" />
      <el-table-column prop="phone" label="电话" />
      <el-table-column prop="email" label="邮箱" />
      <el-table-column label="操作" width="160">
        <template slot-scope="scope">
          <el-button size="mini" @click="handleEdit(scope.row)">编辑</el-button>
          <el-button size="mini" type="danger" @click="handleDelete(scope.row.id)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-pagination
        layout="total, prev, pager, next, jumper"
        :total="total"
        :page-size="pageSize"
        :current-page="currentPage"
        @current-change="handlePageChange"
        style="margin-top: 20px; text-align: center"
    />

    <el-dialog :title="editForm.id ? '编辑学生' : '添加学生'" :visible.sync="dialogVisible">
      <el-form :model="editForm" label-width="80px">
        <el-form-item label="姓名"><el-input v-model="editForm.name" /></el-form-item>
        <el-form-item label="性别">
          <el-select v-model="editForm.gender" placeholder="请选择">
            <el-option label="男" value="男" />
            <el-option label="女" value="女" />
          </el-select>
        </el-form-item>
        <el-form-item label="出生日期"><el-date-picker v-model="editForm.birthday" type="date" placeholder="选择日期" /></el-form-item>
        <el-form-item label="班级"><el-input v-model="editForm.className" /></el-form-item>
        <el-form-item label="专业"><el-input v-model="editForm.major" /></el-form-item>
        <el-form-item label="电话"><el-input v-model="editForm.phone" /></el-form-item>
        <el-form-item label="邮箱"><el-input v-model="editForm.email" /></el-form-item>
      </el-form>
      <div slot="footer">
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submitForm">提交</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import axios from 'axios'
import dayjs from 'dayjs'

export default {
  name: 'StudentList',
  data() {
    return {
      students: [],
      dialogVisible: false,
      editForm: {
        id: null, name: '', gender: '', birthday: '',
        className: '', major: '', phone: '', email: ''
      },
      currentPage: 1,
      pageSize: 5,
      total: 0
    }
  },
  methods: {
    fetchData() {
      axios.get('/api/students', {
        params: {
          page: this.currentPage,
          pageSize: this.pageSize
        }
      }).then(res => {
        this.students = res.data.data || []
        this.total = res.data.totalCount || 0
      })
    },
    handlePageChange(page) {
      this.currentPage = page
      this.fetchData()
    },
    handleAdd() {
      this.editForm = {
        id: null, name: '', gender: '', birthday: '',
        className: '', major: '', phone: '', email: ''
      }
      this.dialogVisible = true
    },
    handleEdit(row) {
      this.editForm = Object.assign({}, row)
      this.dialogVisible = true
    },
    handleDelete(id) {
      this.$confirm('确认删除该学生吗？', '提示', { type: 'warning' })
          .then(() => {
            axios.delete(`/api/students?id=${id}`)
                .then(() => {
                  this.$message.success('删除成功')
                  this.fetchData()
                })
          })
    },
    submitForm() {
      const isEdit = !!this.editForm.id
      const url = '/api/students'
      const method = isEdit ? 'put' : 'post'

      axios({
        method,
        url,
        data: {
          ...this.editForm,
          birthday: this.editForm.birthday
              ? dayjs(this.editForm.birthday).format('YYYY-MM-DD')
              : ''
        }
      }).then(() => {
        this.$message.success(isEdit ? '修改成功' : '添加成功')
        this.dialogVisible = false
        this.fetchData()
      })
    }
  },
  mounted() {
    this.fetchData()
  }
}
</script>

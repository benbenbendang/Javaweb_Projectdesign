<template>
  <div style="padding: 20px">
    <el-button type="primary" @click="dialogVisible = true">添加考勤记录</el-button>

    <el-table :data="records" style="width: 100%; margin-top: 20px">
      <el-table-column prop="id" label="ID" width="60" />
      <el-table-column prop="studentId" label="学生ID" />
      <el-table-column prop="status" label="状态" />
      <el-table-column prop="date" label="日期" />
      <el-table-column label="操作" width="160">
        <template slot-scope="scope">
          <el-button size="mini" @click="handleEdit(scope.row)">编辑</el-button>
          <el-button size="mini" type="danger" @click="handleDelete(scope.row.id)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-pagination
        layout="total, prev, pager, next"
        :total="total"
        :page-size="pageSize"
        :current-page="currentPage"
        @current-change="handlePageChange"
        style="margin-top: 20px; text-align: center"
    />

    <el-dialog :title="form.id ? '编辑考勤' : '添加考勤'" :visible.sync="dialogVisible">
      <el-form :model="form" label-width="80px">
        <el-form-item label="学生ID"><el-input v-model="form.studentId" /></el-form-item>
        <el-form-item label="状态">
          <el-select v-model="form.status" placeholder="请选择">
            <el-option label="出勤" value="出勤" />
            <el-option label="迟到" value="迟到" />
            <el-option label="请假" value="请假" />
            <el-option label="缺勤" value="缺勤" />
          </el-select>
        </el-form-item>
        <el-form-item label="日期">
          <el-date-picker v-model="form.date" type="date" placeholder="选择日期" />
        </el-form-item>
      </el-form>
      <div slot="footer">
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submitForm">提交</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import axios from 'axios'
import dayjs from 'dayjs'

export default {
  data() {
    return {
      records: [],
      form: { id: null, studentId: '', status: '', date: '' },
      dialogVisible: false,
      currentPage: 1,
      pageSize: 5,
      total: 0
    }
  },
  methods: {
    fetchData() {
      axios.get('/api/attendances', {
        params: { page: this.currentPage, pageSize: this.pageSize }
      }).then(res => {
        this.records = res.data.data || []
        this.total = res.data.totalCount || 0
      })
    },
    handlePageChange(page) {
      this.currentPage = page
      this.fetchData()
    },
    handleEdit(row) {
      this.form = { ...row }
      this.dialogVisible = true
    },
    handleDelete(id) {
      this.$confirm('确认删除该记录？', '提示', { type: 'warning' })
          .then(() => {
            axios.delete(`/api/attendances?id=${id}`).then(() => {
              this.$message.success('删除成功')
              this.fetchData()
            })
          })
    },
    submitForm() {
      const isEdit = !!this.form.id
      const method = isEdit ? 'put' : 'post'
      const url = '/api/attendances'

      axios({
        method,
        url,
        data: {
          ...this.form,
          date: this.form.date ? dayjs(this.form.date).format('YYYY-MM-DD') : ''
        }
      }).then(() => {
        this.$message.success(isEdit ? '修改成功' : '添加成功')
        this.dialogVisible = false
        this.fetchData()
      })
    }
  },
  mounted() {
    this.fetchData()
  }
}
</script>